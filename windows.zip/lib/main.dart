import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    runApp(const SneakersApp());
  } catch (e) {
    // Ipapakita ang error sa screen para hindi blangko
    runApp(MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text('Firebase error:\n$e', style: const TextStyle(color: Colors.redAccent)),
          ),
        ),
      ),
    ));
  }
}

// ---------------------------------------------------------------- COLORS (dark theme)
const kBg = Color(0xFF0B0B0F);
const kSurface = Color(0xFF16161D);
const kCard = Color(0xFF1F1F29);
const kAccent = Color(0xFFFA5400); // orange
const kMuted = Color(0xFF9E9EA8);
const kRed = Color(0xFFFF5A36);

// Libreng pictures galing sa Unsplash (free for commercial use)
String unsplash(String id, {int w = 900}) =>
    'https://images.unsplash.com/photo-$id?auto=format&fit=crop&w=$w&q=80';

final String heroImage = unsplash('1542291026-7eec264c27ff');

/// Sample products: brand, price, sizes, picture
final List<Map<String, dynamic>> sampleProducts = [
  {
    'name': 'Air Force 1 High',
    'brand': 'Nike',
    'category': 'Lifestyle',
    'price': 7995,
    'sizes': [7, 8, 9, 10, 11, 12],
    'imageUrl': unsplash('1595950653106-6c9ebd614d3a'),
    'description': 'Classic high-top na may malinis na leather look. Pang-araw-araw na suot, bagay sa kahit anong outfit.',
    'isNew': true,
  },
  {
    'name': 'Air Jordan 1',
    'brand': 'Nike',
    'category': 'Jordan',
    'price': 10295,
    'sizes': [8, 9, 10, 11],
    'imageUrl': unsplash('1628413993904-94ecb60f1239'),
    'description': 'Iconic na Jordan silhouette na paborito ng mga sneakerhead. Matibay at komportable.',
    'isNew': true,
  },
  {
    'name': 'Air Force 1 \'07',
    'brand': 'Nike',
    'category': 'Lifestyle',
    'price': 7595,
    'sizes': [6, 7, 8, 9, 10, 11],
    'imageUrl': unsplash('1712167631738-4dab9e53c853'),
    'description': 'Puting low-top na may cushioned sole. Walang kupas na style.',
    'isNew': false,
  },
  {
    'name': 'Street Runner Red',
    'brand': 'Nike',
    'category': 'Running',
    'price': 6195,
    'sizes': [7, 8, 9, 10, 11],
    'imageUrl': unsplash('1542291026-7eec264c27ff'),
    'description': 'Matapang na pulang kulay at magaan na pakiramdam. Para sa takbo at sa kalye.',
    'isNew': true,
  },
  {
    'name': 'Runner White / Red',
    'brand': 'Nike',
    'category': 'Running',
    'price': 6895,
    'sizes': [6, 7, 8, 9, 10, 11, 12],
    'imageUrl': unsplash('1600185365483-26d7a4cc7519'),
    'description': 'Magaan na running shoe na may breathable na upper at malambot na sole.',
    'isNew': true,
  },
  {
    'name': 'High-Top Court White',
    'brand': 'Nike',
    'category': 'Basketball',
    'price': 5495,
    'sizes': [8, 9, 10, 11, 12],
    'imageUrl': unsplash('1512374382149-233c42b6a83b'),
    'description': 'High-top na may suporta sa bukong-bukong. Bagay sa court at sa labas.',
    'isNew': false,
  },
  {
    'name': 'Training Pro Black / White',
    'brand': 'Nike',
    'category': 'Training & Gym',
    'price': 4995,
    'sizes': [6, 7, 8, 9, 10, 11],
    'imageUrl': unsplash('1605408499391-6368c628ef42'),
    'description': 'Stable at komportable para sa gym at workout. Mahigpit ang kapit sa sahig.',
    'isNew': false,
  },
  {
    'name': 'Street Low Black / Red',
    'brand': 'Nike',
    'category': 'Skateboarding',
    'price': 5295,
    'sizes': [7, 8, 9, 10, 11],
    'imageUrl': unsplash('1615290642882-6b9501729a27'),
    'description': 'Low-top na matibay para sa skate at pang-araw-araw. May grip at padding.',
    'isNew': false,
  },
  {
    'name': 'Chuck Taylor All Star High - Black',
    'brand': 'Converse',
    'category': 'Lifestyle',
    'price': 3495,
    'sizes': [6, 7, 8, 9, 10, 11, 12],
    'imageUrl': unsplash('1565379793984-e65b51b33b37'),
    'description': 'Ang klasikong canvas high-top. Simple, magaan at laging uso.',
    'isNew': false,
  },
  {
    'name': 'Chuck Taylor All Star High - White',
    'brand': 'Converse',
    'category': 'Lifestyle',
    'price': 3495,
    'sizes': [6, 7, 8, 9, 10, 11],
    'imageUrl': unsplash('1528111610157-f0553810b46f'),
    'description': 'Puting canvas high-top na bagay sa casual na porma.',
    'isNew': true,
  },
  {
    'name': 'Chuck Taylor All Star High - Gray',
    'brand': 'Converse',
    'category': 'Lifestyle',
    'price': 3695,
    'sizes': [7, 8, 9, 10, 11],
    'imageUrl': unsplash('1578269174279-27814d45033f'),
    'description': 'Gray na canvas high-top, neutral ang kulay at madaling i-match.',
    'isNew': false,
  },
  {
    'name': 'Chuck Taylor All Star - Blue',
    'brand': 'Converse',
    'category': 'Lifestyle',
    'price': 3495,
    'sizes': [6, 7, 8, 9, 10],
    'imageUrl': unsplash('1641822841761-c1cb29e19420'),
    'description': 'Asul na canvas na nagbibigay ng kulay sa outfit mo.',
    'isNew': true,
  },
  // ---------------- Dagdag na brands at sapatos ----------------
  {
    'name': 'Air Jordan 1 Black / Red',
    'brand': 'Jordan',
    'category': 'Jordan',
    'price': 10995,
    'sizes': [8, 9, 10, 11, 12],
    'imageUrl': unsplash('1552346154-21d32810aba3'),
    'description': 'Black, white at red na colorway ng klasikong Jordan 1. Laging hinahanap ng collectors.',
    'isNew': true,
  },
  {
    'name': 'Trail Runner Green / Black',
    'brand': 'Nike',
    'category': 'Running',
    'price': 6495,
    'sizes': [7, 8, 9, 10, 11],
    'imageUrl': unsplash('1606107557195-0e29a4b5b4aa'),
    'description': 'Matapang na green at black na running shoe. Matibay ang grip at magaan.',
    'isNew': true,
  },
  {
    'name': 'Gray Runner',
    'brand': 'Nike',
    'category': 'Running',
    'price': 5995,
    'sizes': [6, 7, 8, 9, 10, 11, 12],
    'imageUrl': unsplash('1491553895911-0055eca6402d'),
    'description': 'Simpleng gray na running shoe na bagay sa araw-araw na takbo.',
    'isNew': false,
  },
  {
    'name': 'Street Brown',
    'brand': 'Nike',
    'category': 'Lifestyle',
    'price': 6295,
    'sizes': [7, 8, 9, 10, 11],
    'imageUrl': unsplash('1549298916-b41d501d3772'),
    'description': 'Brown na sneaker na may retro na dating. Bagay sa denim at casual na porma.',
    'isNew': false,
  },
  {
    'name': 'Court Classic White / Red',
    'brand': 'Nike',
    'category': 'Basketball',
    'price': 5795,
    'sizes': [8, 9, 10, 11, 12],
    'imageUrl': unsplash('1608667508764-33cf0726b13a'),
    'description': 'Puti at pulang court shoe na may magandang cushioning para sa laro.',
    'isNew': true,
  },
  {
    'name': 'Air Force 1 Low White',
    'brand': 'Nike',
    'category': 'Lifestyle',
    'price': 6995,
    'sizes': [6, 7, 8, 9, 10, 11, 12],
    'imageUrl': unsplash('1579338559194-a162d19bf842'),
    'description': 'Puting low-top na hindi nawawala sa uso. Madaling i-match sa kahit ano.',
    'isNew': false,
  },
  {
    'name': 'Adidas Runner Blue / White',
    'brand': 'Adidas',
    'category': 'Running',
    'price': 5495,
    'sizes': [6, 7, 8, 9, 10, 11],
    'imageUrl': unsplash('1571008887538-b36bb32f4571'),
    'description': 'Asul at puting running shoe na magaan at komportable sa mahabang takbo.',
    'isNew': true,
  },
  {
    'name': 'Adidas Athletic Black / Yellow',
    'brand': 'Adidas',
    'category': 'Training & Gym',
    'price': 4995,
    'sizes': [7, 8, 9, 10, 11, 12],
    'imageUrl': unsplash('1586091827070-ec6c37793c49'),
    'description': 'Black at yellow na athletic shoe para sa gym, training at araw-araw.',
    'isNew': false,
  },
  {
    'name': 'Vans Low-Top Pink',
    'brand': 'Vans',
    'category': 'Skateboarding',
    'price': 3295,
    'sizes': [5, 6, 7, 8, 9, 10],
    'imageUrl': unsplash('1501580979865-c37d96d28bba'),
    'description': 'Pink na low-top na may flat sole. Pang-skate at pang-porma.',
    'isNew': true,
  },
  {
    'name': 'Vans Authentic',
    'brand': 'Vans',
    'category': 'Skateboarding',
    'price': 2995,
    'sizes': [6, 7, 8, 9, 10, 11],
    'imageUrl': unsplash('1553521014-3a56a6964ffe'),
    'description': 'Simpleng canvas low-top. Magaan, madaling isuot at laging uso sa kalye.',
    'isNew': false,
  },
  {
    'name': 'New Balance Classic Pink / Gray',
    'brand': 'New Balance',
    'category': 'Lifestyle',
    'price': 5995,
    'sizes': [6, 7, 8, 9, 10, 11],
    'imageUrl': unsplash('1551107696-a4b0c5a0d9a2'),
    'description': 'Retro na silhouette na pink, gray at puti. Komportable kahit buong araw ang suot.',
    'isNew': true,
  },
];

class SneakersApp extends StatelessWidget {
  const SneakersApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Sneakers shoes',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          snackBarTheme: SnackBarThemeData(
            backgroundColor: kCard,
            contentTextStyle: const TextStyle(color: Colors.white),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          brightness: Brightness.dark,
          scaffoldBackgroundColor: kBg,
          colorScheme: const ColorScheme.dark(primary: kAccent, surface: kSurface),
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.transparent,
            elevation: 0,
            scrolledUnderElevation: 0,
          ),
          filledButtonTheme: FilledButtonThemeData(
            style: FilledButton.styleFrom(
              backgroundColor: kAccent,
              foregroundColor: Colors.black,
              shape: const StadiumBorder(),
              minimumSize: const Size.fromHeight(54),
              textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
            ),
          ),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: kCard,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          ),
        ),
        home: const AuthGate(),
      );
}

/// Magandang background (gradient) para sa lahat ng pages
class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [kBg, Color(0xFF1A1024), Color(0xFF2B1208)],
          ),
        ),
        child: child,
      );
}

/// Kapag naka-login -> Store. Kung hindi -> Login.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          return snap.hasData ? const StorePage() : const LoginPage();
        },
      );
}

// ---------------------------------------------------------------- MODEL / HELPERS
class Product {
  final String id, name, brand, category, imageUrl, description;
  final double price;
  final bool isNew;
  final List<int> sizes;
  Product({
    required this.id,
    required this.name,
    required this.brand,
    required this.category,
    required this.price,
    required this.imageUrl,
    required this.description,
    required this.isNew,
    required this.sizes,
  });
  factory Product.fromMap(String id, Map<String, dynamic> m) => Product(
        id: id,
        name: m['name'] ?? '',
        brand: m['brand'] ?? 'Sneakers',
        category: m['category'] ?? 'Lifestyle',
        price: (m['price'] ?? 0).toDouble(),
        imageUrl: m['imageUrl'] ?? '',
        description: m['description'] ?? '',
        isNew: m['isNew'] ?? false,
        sizes: (m['sizes'] as List?)?.map((e) => (e as num).toInt()).toList() ?? [6, 7, 8, 9, 10, 11, 12],
      );
  Map<String, dynamic> toMap() => {
        'name': name,
        'brand': brand,
        'category': category,
        'price': price,
        'imageUrl': imageUrl,
        'description': description,
        'isNew': isNew,
        'sizes': sizes,
      };
}

String peso(num v) {
  final s = v.toStringAsFixed(0);
  return '₱${s.replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (_) => ',')}';
}

Widget shoeImage(String url, {BoxFit fit = BoxFit.cover}) {
  const fallback = Center(child: Icon(Icons.directions_run, size: 64, color: Colors.white24));
  if (url.isEmpty) return fallback;
  return Image.network(
    url,
    fit: fit,
    width: double.infinity,
    height: double.infinity,
    errorBuilder: (_, __, ___) => fallback,
    loadingBuilder: (context, child, progress) => progress == null
        ? child
        : const Center(child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))),
  );
}

Widget pill(String label, bool selected, VoidCallback onTap) => GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? kAccent : kCard,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Text(label,
            style: TextStyle(color: selected ? Colors.black : Colors.white, fontWeight: FontWeight.w600)),
      ),
    );

DocumentReference<Map<String, dynamic>> get userRef =>
    FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid);

// ---------------------------------------------------------------- STORE
class StorePage extends StatefulWidget {
  const StorePage({super.key});
  @override
  State<StorePage> createState() => _StorePageState();
}

class _StorePageState extends State<StorePage> {
  final categories = const ['All', 'Lifestyle', 'Jordan', 'Running', 'Basketball', 'Football', 'Training & Gym', 'Skateboarding'];
  String selected = 'All';
  String brand = 'All';
  bool searching = false;
  String q = '';

  Query<Map<String, dynamic>> get query {
    final col = FirebaseFirestore.instance.collection('products');
    return selected == 'All' ? col : col.where('category', isEqualTo: selected);
  }

  /// Papalitan ng sample products (may brand, price, size, picture) ang laman ng 'products'
  Future<void> loadSamples() async {
    final db = FirebaseFirestore.instance;
    final col = db.collection('products');
    final old = await col.get();
    final batch = db.batch();
    for (final d in old.docs) {
      batch.delete(d.reference);
    }
    for (final p in sampleProducts) {
      batch.set(col.doc(), p);
    }
    await batch.commit();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Na-load na ang sample products')));
    }
  }

  Widget heroBanner() => Container(
        margin: const EdgeInsets.fromLTRB(16, 14, 16, 6),
        height: 190,
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: const LinearGradient(colors: [Color(0xFFFA5400), Color(0xFFFF9248)]),
          boxShadow: const [BoxShadow(color: Color(0x66FA5400), blurRadius: 24, offset: Offset(0, 10))],
        ),
        child: Stack(
          children: [
            Align(
              alignment: Alignment.centerRight,
              child: FractionallySizedBox(
                widthFactor: 0.58,
                heightFactor: 1,
                child: ShaderMask(
                  shaderCallback: (r) => const LinearGradient(
                    colors: [Colors.transparent, Colors.black],
                    stops: [0.0, 0.45],
                  ).createShader(r),
                  blendMode: BlendMode.dstIn,
                  child: Image.network(heroImage,
                      fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox()),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('NEW SEASON',
                      style: TextStyle(color: Colors.black87, fontWeight: FontWeight.w700, letterSpacing: 2, fontSize: 12)),
                  const SizedBox(height: 6),
                  const Text('Step Into\nThe Heat',
                      style: TextStyle(color: Colors.black, fontSize: 30, fontWeight: FontWeight.w900, height: 1.05)),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(30)),
                    child: const Text('Shop Now', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: searching
            ? TextField(
                autofocus: true,
                decoration: const InputDecoration(hintText: 'Search shoes or brand', prefixIcon: Icon(Icons.search)),
                onChanged: (v) => setState(() => q = v),
              )
            : Text.rich(
                TextSpan(children: [
                  const TextSpan(
                      text: 'SNEAKERS',
                      style: TextStyle(fontWeight: FontWeight.w900, fontStyle: FontStyle.italic, letterSpacing: 1)),
                  TextSpan(
                      text: ' SHOES',
                      style: TextStyle(fontWeight: FontWeight.w300, color: kAccent, letterSpacing: 3, fontSize: 14)),
                ]),
              ),
        actions: [
          IconButton(
            icon: Icon(searching ? Icons.close : Icons.search),
            onPressed: () => setState(() {
              searching = !searching;
              q = '';
            }),
          ),
          IconButton(
            icon: const Icon(Icons.favorite_border),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FavoritesPage())),
          ),
          StreamBuilder<QuerySnapshot>(
            stream: userRef.collection('cart').snapshots(),
            builder: (context, s) => Badge(
              isLabelVisible: (s.data?.docs.length ?? 0) > 0,
              label: Text('${s.data?.docs.length ?? 0}'),
              child: IconButton(
                icon: const Icon(Icons.shopping_bag_outlined),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartPage())),
              ),
            ),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.person_outline),
            onSelected: (v) {
              if (v == 'logout') FirebaseAuth.instance.signOut();
              if (v == 'samples') loadSamples();
              if (v == 'orders') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const OrdersPage()));
              }
              if (v == 'add') {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const AddProductPage()));
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'orders', child: Text('My Orders')),
              PopupMenuItem(value: 'add', child: Text('Add product')),
              PopupMenuItem(value: 'samples', child: Text('Load sample products')),
              PopupMenuItem(value: 'logout', child: Text('Sign Out')),
            ],
          ),
        ],
      ),
      body: AppBackground(
        child: SafeArea(
          top: false,
          child: Column(
            children: [
              Container(
                width: double.infinity,
                color: Colors.black26,
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: const Text('Free Standard Delivery & 30-Day Free Returns',
                    textAlign: TextAlign.center, style: TextStyle(fontSize: 12.5, color: kMuted)),
              ),
              Expanded(
                child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
                  stream: query.snapshots(),
                  builder: (context, snap) {
                    if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
                    if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                    final all = snap.data!.docs.map((d) => Product.fromMap(d.id, d.data())).toList();
                    final brands = ['All', ...{...all.map((p) => p.brand)}];
                    if (!brands.contains(brand)) brand = 'All';
                    final lower = q.toLowerCase();
                    final products = all
                        .where((p) =>
                            (brand == 'All' || p.brand == brand) &&
                            (p.name.toLowerCase().contains(lower) || p.brand.toLowerCase().contains(lower)))
                        .toList();
                    return CustomScrollView(
                      slivers: [
                        if (!searching) SliverToBoxAdapter(child: heroBanner()),
                        SliverToBoxAdapter(
                          child: SizedBox(
                            height: 58,
                            child: ListView.separated(
                              scrollDirection: Axis.horizontal,
                              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                              itemCount: categories.length,
                              separatorBuilder: (_, __) => const SizedBox(width: 8),
                              itemBuilder: (_, i) =>
                                  pill(categories[i], selected == categories[i], () => setState(() => selected = categories[i])),
                            ),
                          ),
                        ),
                        if (brands.length > 2)
                          SliverToBoxAdapter(
                            child: SizedBox(
                              height: 44,
                              child: ListView.separated(
                                scrollDirection: Axis.horizontal,
                                padding: const EdgeInsets.symmetric(horizontal: 16),
                                itemCount: brands.length,
                                separatorBuilder: (_, __) => const SizedBox(width: 8),
                                itemBuilder: (_, i) => ChoiceChip(
                                  label: Text(brands[i] == 'All' ? 'All brands' : brands[i]),
                                  selected: brand == brands[i],
                                  selectedColor: Colors.white24,
                                  backgroundColor: Colors.transparent,
                                  side: const BorderSide(color: Colors.white24),
                                  showCheckmark: false,
                                  onSelected: (_) => setState(() => brand = brands[i]),
                                ),
                              ),
                            ),
                          ),
                        SliverToBoxAdapter(
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(16, 18, 16, 12),
                            child: Text(
                              '${selected == 'All' ? 'Men\'s Shoes' : selected} (${products.length})',
                              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
                            ),
                          ),
                        ),
                        if (products.isEmpty)
                          const SliverFillRemaining(
                            hasScrollBody: false,
                            child: Center(
                                child: Padding(
                              padding: EdgeInsets.all(24),
                              child: Text('Walang nahanap.\nPindutin ang profile icon > Load sample products',
                                  textAlign: TextAlign.center, style: TextStyle(color: kMuted)),
                            )),
                          )
                        else
                          SliverPadding(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            sliver: SliverGrid.builder(
                              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                                maxCrossAxisExtent: 300,
                                crossAxisSpacing: 14,
                                mainAxisSpacing: 14,
                                childAspectRatio: 0.62,
                              ),
                              itemCount: products.length,
                              itemBuilder: (_, i) => ProductCard(product: products[i]),
                            ),
                          ),
                        const SliverToBoxAdapter(child: SizedBox(height: 32)),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Heart button na naka-save sa Firestore: users/{uid}/favorites/{productId}
class FavButton extends StatelessWidget {
  final Product product;
  const FavButton({super.key, required this.product});
  @override
  Widget build(BuildContext context) {
    final ref = userRef.collection('favorites').doc(product.id);
    return StreamBuilder<DocumentSnapshot>(
      stream: ref.snapshots(),
      builder: (context, s) {
        final fav = s.data?.exists ?? false;
        return Material(
          color: Colors.black54,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: () => fav ? ref.delete() : ref.set(product.toMap()),
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Icon(fav ? Icons.favorite : Icons.favorite_border, size: 20, color: fav ? kRed : Colors.white),
            ),
          ),
        );
      },
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;
  const ProductCard({super.key, required this.product});
  @override
  Widget build(BuildContext context) {
    final p = product;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailPage(product: p))),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                children: [
                  Positioned.fill(child: Hero(tag: 'p_${p.id}', child: shoeImage(p.imageUrl))),
                  Positioned(
                    top: 10,
                    left: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(20)),
                      child: Text(p.brand.toUpperCase(),
                          style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 1)),
                    ),
                  ),
                  Positioned(top: 8, right: 8, child: FavButton(product: p)),
                  if (p.isNew)
                    Positioned(
                      bottom: 10,
                      left: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(color: kAccent, borderRadius: BorderRadius.circular(20)),
                        child: const Text('Just In',
                            style: TextStyle(color: Colors.black, fontSize: 11, fontWeight: FontWeight.w800)),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, height: 1.2)),
                  const SizedBox(height: 4),
                  Text('${p.category}  •  US ${p.sizes.first}-${p.sizes.last}',
                      maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: kMuted, fontSize: 12)),
                  const SizedBox(height: 8),
                  Text(peso(p.price), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: kAccent)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- FAVORITES
class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Favorites')),
        body: AppBackground(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: userRef.collection('favorites').snapshots(),
            builder: (context, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final items = snap.data!.docs.map((d) => Product.fromMap(d.id, d.data())).toList();
              if (items.isEmpty) return const Center(child: Text('Wala ka pang favorites', style: TextStyle(color: kMuted)));
              return GridView.builder(
                padding: const EdgeInsets.all(16),
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                    maxCrossAxisExtent: 300, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 0.62),
                itemCount: items.length,
                itemBuilder: (_, i) => ProductCard(product: items[i]),
              );
            },
          ),
        ),
      );
}

// ---------------------------------------------------------------- DETAIL
class ProductDetailPage extends StatefulWidget {
  final Product product;
  const ProductDetailPage({super.key, required this.product});
  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  int? size;

  Future<void> addToBag() async {
    if (size == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pumili muna ng size')));
      return;
    }
    final p = widget.product;
    await userRef.collection('cart').doc('${p.id}_$size').set({
      'name': p.name,
      'brand': p.brand,
      'price': p.price,
      'imageUrl': p.imageUrl,
      'size': size,
      'qty': FieldValue.increment(1),
    }, SetOptions(merge: true));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Added to Bag')));
    }
  }

  Widget infoRow(IconData icon, String text) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(children: [
          Icon(icon, size: 20, color: kAccent),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: const TextStyle(color: kMuted))),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(6),
          child: CircleAvatar(
            backgroundColor: Colors.black54,
            child: IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
          ),
        ),
        actions: [Padding(padding: const EdgeInsets.only(right: 12), child: FavButton(product: p))],
      ),
      bottomNavigationBar: Container(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
        decoration: const BoxDecoration(
          color: kSurface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: SafeArea(
          top: false,
          child: Row(
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Price', style: TextStyle(color: kMuted, fontSize: 12)),
                  Text(peso(p.price), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                ],
              ),
              const SizedBox(width: 20),
              Expanded(child: FilledButton(onPressed: addToBag, child: const Text('Add to Bag'))),
            ],
          ),
        ),
      ),
      body: AppBackground(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            AspectRatio(
              aspectRatio: 1,
              child: Stack(
                children: [
                  Positioned.fill(child: Hero(tag: 'p_${p.id}', child: shoeImage(p.imageUrl))),
                  Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    height: 120,
                    child: const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [Colors.transparent, Color(0xFF1A1024)],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Text(p.brand.toUpperCase(),
                        style: const TextStyle(color: kAccent, fontWeight: FontWeight.w800, letterSpacing: 2)),
                    const SizedBox(width: 10),
                    if (p.isNew)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                        decoration: BoxDecoration(color: kRed, borderRadius: BorderRadius.circular(20)),
                        child: const Text('Just In',
                            style: TextStyle(color: Colors.black, fontSize: 11, fontWeight: FontWeight.w800)),
                      ),
                  ]),
                  const SizedBox(height: 6),
                  Text(p.name, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, height: 1.1)),
                  const SizedBox(height: 4),
                  Text("Men's ${p.category} Shoes", style: const TextStyle(color: kMuted, fontSize: 15)),
                  const SizedBox(height: 10),
                  Text(peso(p.price), style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                  if (p.description.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Text(p.description, style: const TextStyle(color: kMuted, height: 1.5)),
                  ],
                  const SizedBox(height: 24),
                  const Text('Select Size (US)', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      for (final s in p.sizes)
                        GestureDetector(
                          onTap: () => setState(() => size = s),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            width: 62,
                            height: 48,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: size == s ? kAccent : kCard,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: size == s ? kAccent : Colors.white12),
                            ),
                            child: Text('$s',
                                style: TextStyle(
                                    fontWeight: FontWeight.w800, color: size == s ? Colors.black : Colors.white)),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  infoRow(Icons.local_shipping_outlined, 'Free Standard Delivery'),
                  infoRow(Icons.assignment_return_outlined, '30-Day Free Returns'),
                  infoRow(Icons.verified_outlined, 'Authentic at quality-checked'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- ADD PRODUCT
class AddProductPage extends StatefulWidget {
  const AddProductPage({super.key});
  @override
  State<AddProductPage> createState() => _AddProductPageState();
}

class _AddProductPageState extends State<AddProductPage> {
  final name = TextEditingController();
  final brand = TextEditingController();
  final price = TextEditingController();
  final imageUrl = TextEditingController();
  final description = TextEditingController();
  final cats = const ['Lifestyle', 'Jordan', 'Running', 'Basketball', 'Football', 'Training & Gym', 'Skateboarding'];
  String category = 'Lifestyle';
  final Set<int> sizes = {7, 8, 9, 10, 11};
  bool isNew = true;
  bool saving = false;

  Future<void> save() async {
    if (name.text.trim().isEmpty || brand.text.trim().isEmpty || price.text.trim().isEmpty || sizes.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Ilagay ang name, brand, price at kahit isang size')));
      return;
    }
    setState(() => saving = true);
    await FirebaseFirestore.instance.collection('products').add({
      'name': name.text.trim(),
      'brand': brand.text.trim(),
      'category': category,
      'price': double.tryParse(price.text.trim()) ?? 0,
      'imageUrl': imageUrl.text.trim(),
      'description': description.text.trim(),
      'sizes': (sizes.toList()..sort()),
      'isNew': isNew,
    });
    if (!mounted) return;
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Na-add ang product')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Add product')),
        body: AppBackground(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (imageUrl.text.trim().isNotEmpty)
                Container(
                  height: 200,
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), color: kCard),
                  child: shoeImage(imageUrl.text.trim()),
                ),
              const SizedBox(height: 12),
              TextField(
                controller: imageUrl,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  labelText: 'Image link',
                  helperText: 'Right-click ang picture > Copy image address, tapos i-paste dito',
                ),
              ),
              const SizedBox(height: 12),
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Shoe name')),
              const SizedBox(height: 12),
              TextField(controller: brand, decoration: const InputDecoration(labelText: 'Brand (Nike, Adidas, ...)')),
              const SizedBox(height: 12),
              TextField(
                  controller: price,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Price (₱)')),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: category,
                items: [for (final c in cats) DropdownMenuItem(value: c, child: Text(c))],
                onChanged: (v) => setState(() => category = v!),
                decoration: const InputDecoration(labelText: 'Category'),
              ),
              const SizedBox(height: 12),
              TextField(
                  controller: description,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'Description')),
              const SizedBox(height: 16),
              const Text('Available sizes (US)', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final s in [5, 6, 7, 8, 9, 10, 11, 12, 13])
                    pill('$s', sizes.contains(s), () => setState(() => sizes.contains(s) ? sizes.remove(s) : sizes.add(s))),
                ],
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Mark as "Just In"'),
                value: isNew,
                activeColor: kAccent,
                onChanged: (v) => setState(() => isNew = v),
              ),
              const SizedBox(height: 8),
              FilledButton(
                onPressed: saving ? null : save,
                child: saving
                    ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Save product'),
              ),
            ],
          ),
        ),
      );
}

// ---------------------------------------------------------------- CART
class CartPage extends StatelessWidget {
  const CartPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Bag')),
        body: AppBackground(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: userRef.collection('cart').snapshots(),
            builder: (context, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs;
              if (docs.isEmpty) return const Center(child: Text('Walang laman ang bag mo', style: TextStyle(color: kMuted)));
              double total = 0;
              for (final d in docs) {
                total += (d['price'] as num) * (d['qty'] as num);
              }
              return Column(
                children: [
                  Expanded(
                    child: ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: docs.length,
                      itemBuilder: (_, i) {
                        final d = docs[i].data();
                        return Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(18)),
                          child: Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(14),
                                child: SizedBox(width: 84, height: 84, child: shoeImage(d['imageUrl'] ?? '')),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text((d['brand'] ?? '').toString().toUpperCase(),
                                        style: const TextStyle(color: kAccent, fontSize: 11, fontWeight: FontWeight.w800)),
                                    Text(d['name'], style: const TextStyle(fontWeight: FontWeight.w700)),
                                    const SizedBox(height: 4),
                                    Text('US ${d['size']}  •  Qty ${d['qty']}', style: const TextStyle(color: kMuted)),
                                    const SizedBox(height: 4),
                                    Text(peso(d['price']), style: const TextStyle(fontWeight: FontWeight.w800)),
                                  ],
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () => docs[i].reference.delete(),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
                    decoration: const BoxDecoration(
                      color: kSurface,
                      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                    ),
                    child: SafeArea(
                      top: false,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('Total', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                              Text(peso(total), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                            ],
                          ),
                          const SizedBox(height: 12),
                          FilledButton(
                            onPressed: () => Navigator.push(
                                context, MaterialPageRoute(builder: (_) => CheckoutPage(docs: docs, total: total))),
                            child: const Text('Checkout'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      );
}

// ---------------------------------------------------------------- CHECKOUT
class CheckoutPage extends StatefulWidget {
  final List<QueryDocumentSnapshot<Map<String, dynamic>>> docs;
  final double total;
  const CheckoutPage({super.key, required this.docs, required this.total});
  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  final name = TextEditingController();
  final phone = TextEditingController();
  final address = TextEditingController();
  String payment = 'Cash on Delivery';
  bool loading = false;

  Future<void> placeOrder() async {
    if (name.text.trim().isEmpty || phone.text.trim().isEmpty || address.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Kumpletuhin ang details')));
      return;
    }
    setState(() => loading = true);
    final db = FirebaseFirestore.instance;
    final batch = db.batch();
    batch.set(userRef.collection('orders').doc(), {
      'items': widget.docs.map((d) => d.data()).toList(),
      'total': widget.total,
      'name': name.text.trim(),
      'phone': phone.text.trim(),
      'address': address.text.trim(),
      'payment': payment,
      'status': 'Pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
    for (final d in widget.docs) {
      batch.delete(d.reference);
    }
    await batch.commit();
    if (!mounted) return;
    Navigator.of(context).popUntil((r) => r.isFirst);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Order placed! Salamat sa pag-order.')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Checkout')),
        body: AppBackground(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text('Delivery Details', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Full name')),
              const SizedBox(height: 12),
              TextField(
                  controller: phone,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(labelText: 'Phone number')),
              const SizedBox(height: 12),
              TextField(
                  controller: address,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'Complete address')),
              const SizedBox(height: 24),
              const Text('Payment Method', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              for (final m in ['Cash on Delivery', 'GCash', 'Credit / Debit Card'])
                RadioListTile<String>(
                  value: m,
                  groupValue: payment,
                  onChanged: (v) => setState(() => payment = v!),
                  title: Text(m),
                  activeColor: kAccent,
                  contentPadding: EdgeInsets.zero,
                ),
              const Divider(height: 32),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Total', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  Text(peso(widget.total), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                ],
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: loading ? null : placeOrder,
                child: loading
                    ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('Place Order'),
              ),
            ],
          ),
        ),
      );
}

// ---------------------------------------------------------------- ORDERS
class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('My Orders')),
        body: AppBackground(
          child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: userRef.collection('orders').orderBy('createdAt', descending: true).snapshots(),
            builder: (context, snap) {
              if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final docs = snap.data!.docs;
              if (docs.isEmpty) return const Center(child: Text('Wala ka pang orders', style: TextStyle(color: kMuted)));
              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: docs.length,
                itemBuilder: (_, i) {
                  final o = docs[i].data();
                  final items = (o['items'] as List).cast<Map<String, dynamic>>();
                  final dt = (o['createdAt'] as Timestamp?)?.toDate();
                  final date = dt == null ? '' : '${dt.day}/${dt.month}/${dt.year}';
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: kCard, borderRadius: BorderRadius.circular(18)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(date, style: const TextStyle(color: kMuted)),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(color: kAccent, borderRadius: BorderRadius.circular(20)),
                              child: Text(o['status'] ?? 'Pending',
                                  style: const TextStyle(color: Colors.black, fontWeight: FontWeight.w700, fontSize: 12)),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        for (final it in items) Text('${it['qty']}x ${it['name']} (US ${it['size']})'),
                        const SizedBox(height: 8),
                        Text('${o['payment']}  •  ${peso(o['total'])}', style: const TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text(o['address'] ?? '', style: const TextStyle(color: kMuted)),
                      ],
                    ),
                  );
                },
              );
            },
          ),
        ),
      );
}

// ---------------------------------------------------------------- LOGIN
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final pass = TextEditingController();
  bool loading = false;

 Future<void> submit({required bool signUp}) async {
  debugPrint('EMAIL: "${email.text}" PASS length: ${pass.text.length}');
  if (email.text.trim().isEmpty || pass.text.isEmpty) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Ilagay muna ang email at password')),
    );
    return;
  }
  setState(() => loading = true);
  // ...ang natitirang code mo
    setState(() => loading = true);
    try {
      final auth = FirebaseAuth.instance;
      if (signUp) {
        await auth.createUserWithEmailAndPassword(email: email.text.trim(), password: pass.text);
      } else {
        await auth.signInWithEmailAndPassword(email: email.text.trim(), password: pass.text);
      }
  } on FirebaseAuthException catch (e) {
  if (mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${e.code}: ${e.message}')),
    );
  }
} catch (e) {
  debugPrint('SIGNUP ERROR: $e');
  if (mounted) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Error: $e')),
    );
  }
}
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Stack(
          children: [
            const AppBackground(child: SizedBox.expand()),
            Positioned.fill(
              child: Opacity(
                opacity: 0.35,
                child: Image.network(heroImage, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox()),
              ),
            ),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [kBg.withOpacity(0.55), kBg.withOpacity(0.92)],
                  ),
                ),
              ),
            ),
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: ListView(
                  shrinkWrap: true,
                  padding: const EdgeInsets.all(24),
                  children: [
                    const Text('SNEAKERS',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 40, fontWeight: FontWeight.w900, fontStyle: FontStyle.italic, letterSpacing: 1)),
                    Text('S H O E S',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: kAccent, fontWeight: FontWeight.w300, letterSpacing: 6)),
                    const SizedBox(height: 8),
                    const Text('Sign in to your account', textAlign: TextAlign.center, style: TextStyle(color: kMuted)),
                    const SizedBox(height: 32),
                    TextField(controller: email, decoration: const InputDecoration(labelText: 'Email')),
                    const SizedBox(height: 12),
                    TextField(
                        controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
                    const SizedBox(height: 20),
                    FilledButton(
                      onPressed: loading ? null : () => submit(signUp: false),
                      child: loading
                          ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2))
                          : const Text('Sign In'),
                    ),
                    TextButton(
                        onPressed: loading ? null : () => submit(signUp: true),
                        child: const Text('Join Us (Create account)', style: TextStyle(color: kAccent))),
                  ],
                ),
              ),
            ),
          ],
        ),
      );
}